# CSE380-Project SPaR(Scissors Paper and Rock)

Our design doc is located at: https://spar-scissors-paper-and-rock.firebaseapp.com/benchmark1/benchmark1.html or https://spar-scissors-paper-and-rock.web.app/benchmark1/benchmark1.html
